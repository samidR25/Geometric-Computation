[x y] = ginput;
x(length(x) + 1) = x(1);
y(length(y) + 1) = y(1);
hold on;
plot(x, y, 'b-');
while 1
[x1 y1] = ginput(1);
p = [x1 y1];
node = [x y];
[in,bnd] = inpoly(p,node);
plot(p(in,1),p(in,2),'b*',p(~in,1),p(~in,2),'r*',p(bnd,1),p(bnd,2),'g*');
end

