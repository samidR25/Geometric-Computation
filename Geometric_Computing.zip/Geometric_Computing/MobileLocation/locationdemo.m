xx = [
    0.4459
    0.3675
    0.5565
];

yy =[
    
    0.5980
    0.3845
    0.4605
];

rr = [
     0.25
     0.2
     0.15
     ];

figure;
hold on;
axis equal;
for i = 1:length(xx)
    p = circle_imp_points_2d(rr(i), [xx(i), yy(i)], 30);
    plot([p(1, :) p(1, 1)], [p(2, :), p(2, 1)], 'b');
end

cints = [];

for i = 1:length(xx)
    for j = i+1:length(xx)
        [num, p] = circles_imp_int_2d(rr(i), [xx(i), yy(i)], rr(j), [xx(j), yy(j)]);
        if (num == 1 | num == 2)
            for k = 1:2
                plot(p(1, k), p(2, k), 'gx');
                valid = 1;
                for t = 1:length(xx)
                    if (t ~= i & t ~= j)
                        d = [p(1, k) - xx(t), p(2 , k) - yy(t)];
                        if norm(d) > rr(t)
                            valid = 0;
                            break;
                        end
                    end
                end
                if (valid)
                    cints = [cints; p(1, k), p(2, k)];
                end
            end
        end
    end
end

cints
plot(cints(:, 1), cints(:, 2), 'ro');
