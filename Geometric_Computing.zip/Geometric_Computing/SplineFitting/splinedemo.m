xx = [];
yy = [];
axis([-1, 1, -1, 1]);
while (1)
    [x y] = ginput(1)
    xx = [xx x];
    yy = [yy y];
    if (length(xx) > 1)
        lx = linspace(min(xx), max(xx), 100);
        ly = spline(xx, yy, lx);
        plot(xx, yy, 'ro', lx, ly, 'b');
        axis([-1, 1, -1, 1]);
    end
end