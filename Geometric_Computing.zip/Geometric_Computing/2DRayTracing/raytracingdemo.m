function raytracingdemo(dx, dy)
% This demonstrates 2D ray tracing algorithm.

% arrays representing 'objects'

xx=[
    0.0288
    0.3906
    0.1786
    0.5127
    0.4666
    0.7500
    0.7615
    0.9159
    0.6509
    0.8214
];
yy=[
    0.9401
    0.9079
    0.2740
    0.1877
    0.8202
    0.9108
    0.7354
    0.4196
    0.1915
    0.2442
];

% show the objects
hold on;
for i=1:2:length(xx)
    plot(xx(i:i+1), yy(i:i+1), 'r');
end

% centre position
cx = 0.05;
cy = 0.6;
plot(cx, cy, 'og');

% direction vector
%dx = 1;
%dy = 1.2;

% starting point (initialised to centre)
sx = cx;
sy = cy;
count = 0;
while count < 10
   count = count + 1;
   disp(count);
   nx = [];
   ny = [];
   nt = [];
   lx = [];
   ly = [];
   for i = 1:2:length(xx)
       [t1, t2, pi] = lines_par_int_2d(dx, dy, sx, sy, xx(i+1)-xx(i), yy(i+1)-yy(i), xx(i), yy(i));
        if t1 > 0.0001 & t2 >= 0 & t2 <= 1 & (isempty(nt) | t1 < nt) % choose the closest intersection
            nt = t1;
            nx = pi(1);
            ny = pi(2);
            lx = xx(i+1) - xx(i);
            ly = yy(i+1) - yy(i);
        end
   end
   if ~isempty(nt) % if exists
       plot([sx nx], [sy ny], 'b');
       disp([sx sy nx ny]);
       sx = nx;
       sy = ny;
       v1 = [dx dy];
       v2 = [lx ly];
       v1 = v1 / norm(v1);
       v2 = v2 / norm(v2);
       v3 = 2 * (v1 * v2') * v2 - v1;
       dx = v3(1);
       dy = v3(2);
   else
       plot([sx sx+dx*0.1], [sy, sy+dy*0.1], 'b');
       break;
   end
end
