figure
raytracingdemo(1, 1.2)
pause
raytracingdemo(1, 1.8)
pause
raytracingdemo(1, 3.5)
