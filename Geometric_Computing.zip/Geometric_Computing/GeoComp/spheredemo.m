
%  n = 100;
% X = 2*pi*rand(2,N);
% r = .2;
% Y = HyperSphere(X,r);
% plot3(Y(1,:),Y(2,:),Y(3,:),'r.');
% 
% N = 1000;
% X = linspace(0.16,.45*pi, N);
% r = 0.2;
% Y = HyperSphere(X,r);
% plot(Y(1,:),Y(2,:),'r.');

% oxygen=[0.1283 1.1207 1.9259];
% hydrogen1=[0.1291 1.1709 1.8394];
% hydrogen2=[0.2223 1.1052 1.9564];
% figure(1)
% hold on
% plot3(oxygen(1),oxygen(2),oxygen(3),'r.')
% plot3(hydrogen1(1),hydrogen1(2),hydrogen1(3),'k.')
% plot3(hydrogen2(1),hydrogen2(2),hydrogen2(3),'k.')
% [oxygen,hydrogen1,hydrogen2] = sphere(n);
% % plot3(oxygen,hydrogen1,hydrogen2)
% surf(oxygen,hydrogen1,hydrogen2)
% % surf(X+Xc,Y+Yc,Z+Zc)
% hold off







plot3([1 3], [1 4], [1 5], '*-');
grid on; axis equal; xlabel('x'); ylabel('y'); zlabel('z');










